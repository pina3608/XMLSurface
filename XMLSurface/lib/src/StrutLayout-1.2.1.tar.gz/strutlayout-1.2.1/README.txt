StrutLayout
Copyright (c) 1998 Matthew Phillips <mpp@ozemail.com.au>


1. Overview

   StrutLayout is an AWT layout manager that lays out components by
   logically connecting them with struts.  Each StrutLayout has a root
   component which any number of child components may connect to.
   Each child component may have also have child components, and so
   on.
                           
   Components in a StrutLayout may also have internal springs
   associated with them.  These springs are used to make the component
   expand horizontally and/or vertically to take up any extra space.
   The expansion takes into account any child components, ensuring
   they are not pushed off the edge of the layout area.

   Additionally, each component may be a member of a size group which
   allows groups of components to maintain the same horizontal and/or
   vertical dimensions as the largest component in the group.

2. Use

   StrutLayout consists of a single main class plus a number of inner
   classes in the matthew.awt package.  The bytecode for StrutLayout
   is included in the classes subdirectory: to use it in your programs
   just include STRUTLAYOUT_HOME/classes in your CLASSPATH and import
   matthew.awt.StrutLayout in the source.  See
   src/test/TestStrutLayout.java for an example of using StrutLayout.

3. Documentation

   The javadoc API documentation is contained in the javadoc
   subdirectory.

4. Limitations

   Over the last few years there have been a number of different
   layout managers based on springs and struts developed for Java.
   Perhaps most notably, JavaSoft intended to include such a layout
   manager in the JFC 1.1 release, but after extensive work this
   project was dropped as the layout proved to be unacceptably buggy
   and slow.  This highlights a general problem with the concept: to
   humans the behaviour of objects connected by springs and struts is
   simple, but actually explaining it to a computer is extremely
   difficult.

   The aim with StrutLayout has been to support the springs and struts
   concept, but to leave out the features that make full
   implementations of these layouts hopelessly slow and complex (even
   so, StrutLayout has grown to nearly 1,000 lines of Java source
   code).  For example, StrutLayout does not allow you to use struts
   to connect components to the container's walls.  You also cannot
   use multiple struts to to make parent components stretch a child
   component.  These simplifications allow StrutLayout to guarantee an
   upper bound on layout time (proportional to the number of
   components managed) and to have a minimum of strange special-case
   bugs.

   In any case, StrutLayout's springs and size groups can almost
   always produce the same effects at a much lower cost.  And where
   the desired results are not possible directly with StrutLayout,
   using sub-panels will usually solve the problem.

   Some rules for correctly using StrutLayout are:

     * There may only be one root component.  There is no way to
       specify an absolute position for the root component, but a
       combination of setting the container's insets and layout
       alignment (see setAlignment()) works better anyway.

     * The components must be strictly connected to form a tree.
       Thus, a child component may only have one parent.  Bad things
       will happen if there is a cycle in the chain of struts.

     * Parent components don't care if child components overlap.  For
       example, StrutLayout will NOT automatically resize parent to
       ensure child 1 and child 2 do not overlap:

          ----------------------
         |        parent        |
          ----------------------
         |                      |
          ---------    ---------
         | child 1 |  | child 2 |
          ---------    ---------


5. Author

   This software was written by Matthew Phillips <mpp@ozemail.com.au>
   (http://www.ozemail.com.au/~mpp).  Why he did it, only he knows.
   Hopefully someone will find it worth all the work he put into it.

6. License

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License
   as published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.
  
   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA.

--
$Id: README.txt,v 1.4 1998/07/04 03:38:30 matt Exp $